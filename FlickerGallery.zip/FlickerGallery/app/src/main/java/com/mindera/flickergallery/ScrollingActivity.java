package com.mindera.flickergallery;

import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;

import com.mindera.flickergallery.adapter.KittenAdapter;
import com.mindera.flickergallery.options.RetrofitConfig;
import com.mindera.flickergallery.service.RetrofitService;
import com.mindera.flickergallery.to.Kitten;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScrollingActivity extends AppCompatActivity {
    String METHOD_SEARCH = "flickr.photos.search";
    int page = 1;
    private RecyclerView rvNumbers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolBarLayout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        toolBarLayout.setTitle(getTitle());

        rvNumbers = findViewById(R.id.rvNumbers);

        callKitten();
    }

    public void callKitten() {
        Call<Kitten> call = new RetrofitConfig().getKittensService().getKittens(METHOD_SEARCH,
                RetrofitService.API_KEY,
                RetrofitService.TAGS_KITTEN,
                page,
                RetrofitService.FORMAT,
                RetrofitService.NO_JSON_CALLBACK);

        call.enqueue(new Callback<Kitten>() {
            @Override
            public void onResponse(Call<Kitten> call, Response<Kitten> response) {
                Kitten miau = response.body();

//                for (int i=0; i < miau.getPhotos().getPhoto().size(); i++){
//                    ImageMiauView miauView = new ImageMiauView(ScrollingActivity.this, miau.getPhotos().getPhoto().get(i).getId());
//
//                    rvNumbers.addView(miauView);
//                }

                int numberOfColumns = 2;
                rvNumbers.setLayoutManager(new GridLayoutManager(getApplicationContext(), numberOfColumns));
                KittenAdapter adapter = new KittenAdapter(getApplicationContext(), miau.getPhotos().getPhoto());
                rvNumbers.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<Kitten> call, Throwable t) {
                Log.e("Kitten: ", "Error to search miau:" + t.getMessage());
            }
        });
    }
}